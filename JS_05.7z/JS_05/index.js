// Task 0
function createArray(num) {
  let arr = [];
  for (let i = 1; i <= num; i++) {
    arr.push(i);
  }
  console.log(arr);
  return arr;
}

createArray(6);

// Task 1
function getFirstValue(arra) {
  let firstElement = arra.shift();
  console.log(`The first element of your array is ${firstElement}`);
}

getFirstValue([1, 2, 3]);
getFirstValue([6, 4, 6, 4, 6, 4, 6, 4]);

// Task 2
function reverseArr(ari) {
  let reversedArr = [];
  for (let j = ari.length - 1; j >= 0; j--) {
    reversedArr.push(ari[j]);
  }
  return reversedArr;
}

let myArray = createArray(8);
let myArrayReversed = reverseArr(myArray);
console.log(myArray);
console.log(myArrayReversed);

// Task 3
function search(array1, indexNumber) {
  let james;
  for (let k = 0; k < array1.length; k++) {
    return (james = array1.indexOf(indexNumber));
  }
}

console.log(search([1, 2, 3, 4], 4));

// Task 3 a different way
function findIndexInArr(array2, element2) {
  for (let i = 0; i < array2.length; i++) {
    if (array2[i] === element2) {
      return i;
    }
  }
  return -1;
}

console.log(findIndexInArr([1, 2, 3, 4], 4));

// Task 4
// Kolku koloni sakate i kolku redici i da generirate tabela
// i taa tabela da se izgenerira na HTML
// It works and i have no idea how :)
function tableCreate(rows, columns) {
  const body = document.getElementsByTagName("body")[0];
  const tbl = document.createElement("table");
  tbl.style.width = "100%";
  tbl.setAttribute("border", "1");
  let tbdy = document.createElement("tbody");
  for (let i = 0; i < rows; i++) {
    let tr = document.createElement("tr");
    for (let j = 0; j < columns; j++) {
      if (i == rows - 1 && j == columns) {
        break;
      } else {
        let td = document.createElement("td");
        td.appendChild(document.createTextNode("\u0020"));
        i == rows[i] && j == columns[j]
          ? td.setAttribute("rowSpan", `${rows}`)
          : null;
        tr.appendChild(td);
      }
    }
    tbdy.appendChild(tr);
  }
  tbl.appendChild(tbdy);
  body.appendChild(tbl);
}
tableCreate(6, 6);

// Task 5
// Check if an Array
function checkArray(array3, element3) {
  for (let i = 0; i < array3.length; i++) {
    if (array3[i] === element3) {
      return true;
    }
  }
  return false;
}

console.log(checkArray([1, 2, 3, 4], 4));

// Task 6
// Negate the Array of numbers ( make them negative values ) ( just multiply an array by (-1))
function negate(vmro) {
  let tesla = [];
  for (let i = 0; i < vmro.length; i++) {
    tesla.push(vmro[i] * -1);
  }
  return tesla;
}

console.log(negate([1, 2, 3, 4]));

// Task 7 (6 ustvari ama aj) Difference between minimum and
// maximum number in array
function difMaxMin(arr) {
  let min = +Infinity;
  let max = -Infinity;
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] > max)
      //if you only have 1 statement you dont need curly braces
      max = arr[i];
    if (arr[i] < min) min = arr[i];
  }
  return max - min;
}

console.log(difMaxMin([1, 4, 5, 8, 9, 74]));
